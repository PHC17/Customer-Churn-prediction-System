# Churnly: Customer Churn Prediction System

End-to-end churn project on 64,374 customers: data audit, EDA, six models, tuning, a validated prediction
service with risk bands and retention playbooks, and a Streamlit dashboard (SHAP, threshold slider,
batch CSV scoring, cost-benefit simulator).

> **Read this first.** Scores on this dataset are near-perfect (XGBoost F1 = 0.9998) because its labels follow
> near-deterministic rules: a single depth-8 decision tree reaches ~99.5% CV accuracy and `CustomerID` alone
> perfectly separates churners above ID 50,000. This is typical of synthetic data. Treat the numbers as a ceiling,
> not as expected accuracy on real customers.

## Project structure

```
churn_project/
├── app.py                      # Streamlit dashboard (8 pages)
├── requirements.txt
├── .streamlit/config.toml      # theme + upload limit + XSRF protection
├── data/customer_churn_dataset-testing-master.csv
├── notebooks/churn_analysis.ipynb   # Tasks 1-21, executed, with insights
├── src/
│   ├── config.py               # paths, seed, schema, bounds, business defaults
│   ├── data_loader.py          # load, clean, split (Tasks 1-3, 8, 9)
│   ├── preprocessing.py        # feature engineering, encoding, scaling (Tasks 10, 15)
│   ├── models.py               # 6 models + search spaces (Tasks 11, 15, 16)
│   ├── evaluation.py           # metrics, confusion, importance, cost-benefit (Tasks 12-14)
│   ├── predictor.py            # validation, risk bands, recommendations, SHAP (Tasks 17-19)
│   └── train.py                # full pipeline -> artifacts/
└── artifacts/                  # best_model.joblib (+ .sha256), report.json, test_scores.csv
```

## Run it

```bash
python -m venv .venv && source .venv/bin/activate      # Python 3.11+
pip install -r requirements.txt

python -m src.train          # ~4 min: trains 6 models, tunes the best, writes artifacts/
streamlit run app.py         # opens http://localhost:8501
jupyter lab notebooks/churn_analysis.ipynb             # optional: the full 21-task walkthrough
```

Artifacts are included, so `streamlit run app.py` works immediately; re-run `src.train` to regenerate them.

## Key findings

| Driver | Observation |
|---|---|
| Payment delay | ~10% churn up to 15 days, 59-77% beyond. Strongest single driver. |
| Support calls | ~24% up to 3 calls, ~61% from 5 calls. |
| Compounding | 5+ calls **and** >15 days delay: 84% churn. Neither: 5%. |
| Usage | <= 5 uses/month: 65% churn vs ~43%. |
| Contract / gender | Monthly 52%, quarterly 44%, annual 46%. Women 55% vs men 39%. |
| Tenure | Customers beyond 24 months churn *more* (56% vs 32%). |
| No signal | Subscription type, last interaction. |

### Model comparison (held-out 20%, stratified, seed 42)

| Model | F1 | ROC-AUC | Scaling needed |
|---|---|---|---|
| XGBoost | 1.0000 | 1.0000 | no |
| LightGBM | 1.0000 | 1.0000 | no |
| Random Forest | 0.9993 | 1.0000 | no |
| SVM (RBF) | 0.9392 | 0.9891 | yes |
| KNN | 0.9247 | 0.9823 | yes |
| Logistic Regression | 0.8171 | 0.9023 | yes |

Final model: **tuned XGBoost** (RandomizedSearchCV, 30 candidates x 5-fold CV): accuracy 0.9998, precision 0.9997,
recall 1.0000, F1 0.9998. Tuning and feature engineering gave no meaningful gain because the baseline is already at the
ceiling. Linear models lose because churn depends on thresholds and interactions.

## Key decisions

* **CustomerID removed**: it is a row counter sorted by outcome (label leakage).
* **Encoding**: ordinal for Subscription and Contract (natural order), single 0/1 column for Gender.
* **Scaling**: `StandardScaler` only for LR / SVM / KNN, fit inside the pipeline on training data only.
* **Selection metric**: F1, because a missed churner (lost lifetime value) costs several times a wasted offer.
* **Gender-blind recommendations**: gender is predictive but never used to choose a treatment.
* **Risk bands**: Low < 35%, Medium 35-65%, High >= 65% (configurable in `config.py`).

## Security and robustness

* All inputs (form and CSV) are validated for type, numeric bounds and a closed category set before scoring.
* CSV uploads: 10 MB / 100,000-row caps, parse errors handled, exported text cells neutralised against spreadsheet
  formula injection, user-supplied IDs never rendered as HTML.
* Model file integrity: SHA-256 digest verified before `joblib.load` (which unpickles). Only load models you trained.
* Model artifacts are written atomically (temp file + `os.replace`), so a running app never reads a half-written model
  during a retrain (race condition avoided). Streamlit caches the model per process via `st.cache_resource`.
* Streamlit XSRF protection enabled; no user text is interpolated into unsafe HTML.

## Performance notes

| Step | Complexity (n rows, d features, T trees) |
|---|---|
| Logistic Regression | O(n·d) per iteration |
| Random Forest | O(T·n·log n·√d) train, O(T·depth) per prediction |
| XGBoost / LightGBM (histogram) | ~O(T·n·d) train, O(T·depth) per prediction |
| SVM (RBF) | O(n²) to O(n³) train: the slowest here (~30 s on 51k rows) and impractical beyond ~200k rows |
| KNN | O(1) train, O(n·d) *per prediction*: scales worst at serving time |

Measured: scoring 20,000 customers takes ~0.5 s; one SHAP explanation ~0.6 s.

## Limitations

1. Synthetic-looking data: expect lower, noisier metrics on real customers; re-validate before acting.
2. The best model was picked on the test set among near-tied candidates; with real data use nested CV or a validation set.
3. Cost-benefit uses illustrative defaults (customer value 500, offer cost 50, success 35%). Replace with real numbers.
4. SHAP values are in log-odds and explain the model, not causality.

## Roadmap ideas

* **Uplift modelling**: predict who is *persuadable* by an offer, not just who will churn, to avoid spending on sure-things.
* **Calibration + drift monitoring**: weekly scoring job with PSI drift alerts and calibration curves.
* **Auto-A/B harness**: randomise playbooks in production to measure true offer success rates and feed them back into the ROI page.
* **Survival analysis** (time-to-churn) for proactive timing of interventions.
* **Natural-language explanations**: turn SHAP + rules into a one-paragraph account-manager briefing.
