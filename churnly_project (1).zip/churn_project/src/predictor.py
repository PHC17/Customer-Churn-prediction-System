"""Prediction service: validation, risk bands, recommendations, SHAP (Tasks 17-19).

Security notes
--------------
* Every external value (form or CSV) passes through ``validate_frame``: strict
  numeric coercion, bounds, and a closed set of categories. Nothing is ever
  evaluated, formatted into code, or passed to a shell.
* The model artifact is verified against a SHA-256 digest before
  ``joblib.load`` (which unpickles). Never load a model file you did not train.
* Artifacts are written atomically (temp file + ``os.replace``) so a reader can
  never observe a half-written model while a retrain is running.
"""
from __future__ import annotations

import hashlib
import os
import tempfile

import joblib
import numpy as np
import pandas as pd

from . import config as C
from .models import TREE_MODELS
from .preprocessing import transformed_frame


# ---------------------------------------------------------------- validation
def validate_frame(df: pd.DataFrame) -> pd.DataFrame:
    """Validate and normalise raw customer rows. Raises ValueError with a clear message."""
    missing = [c for c in C.FEATURE_ORDER if c not in df.columns]
    if missing:
        raise ValueError(f"Missing required column(s): {', '.join(missing)}")
    out = df[C.FEATURE_ORDER].copy()

    for col, (lo, hi) in C.FEATURE_BOUNDS.items():
        out[col] = pd.to_numeric(out[col], errors="coerce")
        bad = out[col].isna() | (out[col] < lo) | (out[col] > hi)
        if bad.any():
            first = int(np.flatnonzero(bad.to_numpy())[0]) + 1
            raise ValueError(
                f"'{col}' must be a number between {lo} and {hi} "
                f"({int(bad.sum())} invalid row(s); first at row {first})."
            )
    for col, allowed in C.CATEGORICAL_VALUES.items():
        out[col] = out[col].astype(str).str.strip().str.title()
        bad = ~out[col].isin(allowed)
        if bad.any():
            raise ValueError(
                f"'{col}' must be one of {allowed} ({int(bad.sum())} invalid row(s))."
            )
    return out.reset_index(drop=True)


# ------------------------------------------------------------- model storage
def _sha256(path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def save_bundle(bundle: dict) -> None:
    """Atomically persist the model bundle plus its integrity digest."""
    C.ARTIFACT_DIR.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=C.ARTIFACT_DIR, suffix=".tmp")
    os.close(fd)
    try:
        joblib.dump(bundle, tmp, compress=3)
        digest = _sha256(tmp)
        os.replace(tmp, C.MODEL_PATH)
    finally:
        if os.path.exists(tmp):
            os.remove(tmp)
    C.MODEL_HASH_PATH.write_text(digest)


def load_bundle() -> dict:
    """Load the trained bundle after verifying its checksum."""
    if not C.MODEL_PATH.exists() or not C.MODEL_HASH_PATH.exists():
        raise FileNotFoundError("Model not found. Run `python -m src.train` first.")
    if _sha256(C.MODEL_PATH) != C.MODEL_HASH_PATH.read_text().strip():
        raise RuntimeError("Model integrity check failed (checksum mismatch).")
    return joblib.load(C.MODEL_PATH)


# --------------------------------------------------------------- predictions
def risk_category(p: float) -> str:
    if p < C.RISK_LOW_MAX:
        return "Low"
    if p < C.RISK_HIGH_MIN:
        return "Medium"
    return "High"


def predict_frame(bundle: dict, df: pd.DataFrame, threshold: float = 0.5) -> pd.DataFrame:
    """Score validated rows. Returns probability, label and risk band per row."""
    X = validate_frame(df)
    probs = bundle["pipeline"].predict_proba(X)[:, 1]
    out = X.copy()
    out["Churn Probability"] = probs
    out["Prediction"] = np.where(probs >= threshold, "Yes", "No")
    out["Risk"] = [risk_category(p) for p in probs]
    return out


def predict_one(bundle: dict, row: dict, threshold: float = 0.5) -> dict:
    res = predict_frame(bundle, pd.DataFrame([row]), threshold).iloc[0]
    return {
        "probability": float(res["Churn Probability"]),
        "prediction": res["Prediction"],
        "risk": res["Risk"],
    }


# ----------------------------------------------------------- recommendations
def risk_factors(row: dict) -> list[dict]:
    """Rule-based risk drivers using thresholds found in the EDA.

    Thresholds reflect step-changes in observed churn rate: support calls >= 5
    (24% -> 61%), payment delay > 15 days (10% -> 59-77%), usage <= 5 per month
    (43% -> 65%), monthly contracts (52% vs 44-46%).
    Gender is deliberately NOT used to choose a treatment (fairness).
    """
    f = []
    if row["Support Calls"] >= 5:
        f.append({
            "factor": f"High support contact ({int(row['Support Calls'])} calls)",
            "action": "Assign a customer-success owner, review ticket root causes and "
                      "call back within 24 hours.",
        })
    if row["Payment Delay"] > 15:
        f.append({
            "factor": f"Late payments ({int(row['Payment Delay'])} days delay)",
            "action": "Offer a flexible payment plan or auto-pay incentive and send "
                      "a friendly billing reminder.",
        })
    if row["Usage Frequency"] <= 5:
        f.append({
            "factor": f"Low engagement ({int(row['Usage Frequency'])} uses/month)",
            "action": "Trigger an onboarding / feature-discovery campaign with "
                      "personalised usage tips.",
        })
    if row["Contract Length"] == "Monthly":
        f.append({
            "factor": "Month-to-month contract",
            "action": "Offer a discount to move to a quarterly or annual plan.",
        })
    if row["Tenure"] > 24:
        f.append({
            "factor": f"Long-tenure customer ({int(row['Tenure'])} months)",
            "action": "Send a loyalty reward and ask for feedback on unmet needs; "
                      "long-tenure customers churn more in this data.",
        })
    if row["Total Spend"] < 300:
        f.append({
            "factor": f"Low lifetime spend ({int(row['Total Spend'])})",
            "action": "Present a value bundle or usage-based upgrade trial.",
        })
    return f


RISK_PLAYBOOK = {
    "High": "Immediate outreach by the retention team within 48 hours with a "
            "personalised offer. Escalate if there is no response.",
    "Medium": "Enrol in a targeted email / in-app nurture campaign and re-score "
              "weekly. Intervene early on the top risk factor.",
    "Low": "No intervention needed. Keep nurturing with loyalty perks and referral "
           "prompts; avoid over-discounting.",
}


def recommendations(row: dict, risk: str) -> dict:
    return {"headline": RISK_PLAYBOOK[risk], "factors": risk_factors(row)}


# ---------------------------------------------------------------------- SHAP
def shap_explain(bundle: dict, row: dict, top_n: int = 10):
    """Per-feature SHAP contribution (log-odds) for a single customer.

    Returns None for non-tree models (TreeExplainer only).
    """
    if bundle["name"] not in TREE_MODELS:
        return None
    import shap

    pipe = bundle["pipeline"]
    X = validate_frame(pd.DataFrame([row]))
    Xt = transformed_frame(pipe, X)
    explainer = shap.TreeExplainer(pipe[-1])
    sv = explainer.shap_values(Xt)
    if isinstance(sv, list):
        sv = sv[1]
    sv = np.asarray(sv)
    if sv.ndim == 3:
        sv = sv[:, :, 1]
    out = pd.DataFrame({
        "Feature": Xt.columns,
        "Value": Xt.iloc[0].to_numpy(),
        "SHAP": sv[0],
    })
    out["abs"] = out["SHAP"].abs()
    return out.sort_values("abs", ascending=False).head(top_n).drop(columns="abs")
