"""Metrics, confusion matrix, feature importance and cost-benefit (Tasks 12-14, 19)."""
from __future__ import annotations

import numpy as np
import pandas as pd
from sklearn.metrics import (accuracy_score, confusion_matrix, f1_score,
                             precision_score, recall_score, roc_auc_score,
                             roc_curve)

from .models import TREE_MODELS
from .preprocessing import transformed_frame


def get_scores(pipe, X) -> np.ndarray:
    """Churn score in [0,1] for probabilistic models; raw margin for SVC."""
    est = pipe[-1]
    if hasattr(est, "predict_proba"):
        return pipe.predict_proba(X)[:, 1]
    return pipe.decision_function(X)


def compute_metrics(y_true, y_pred, y_score) -> dict:
    return {
        "Accuracy": accuracy_score(y_true, y_pred),
        "Precision": precision_score(y_true, y_pred, zero_division=0),
        "Recall": recall_score(y_true, y_pred, zero_division=0),
        "F1": f1_score(y_true, y_pred, zero_division=0),
        "ROC-AUC": roc_auc_score(y_true, y_score),
    }


def evaluate(pipe, X, y, threshold: float | None = None) -> tuple[dict, np.ndarray]:
    """Return (metrics, scores). ``threshold`` applies to probabilistic models."""
    scores = get_scores(pipe, X)
    if threshold is None or not hasattr(pipe[-1], "predict_proba"):
        pred = pipe.predict(X)
    else:
        pred = (scores >= threshold).astype(int)
    return compute_metrics(y, pred, scores), scores


def roc_points(y_true, scores, max_points: int = 200) -> dict:
    fpr, tpr, _ = roc_curve(y_true, scores)
    idx = np.unique(np.linspace(0, len(fpr) - 1, max_points).astype(int))
    return {"fpr": fpr[idx].tolist(), "tpr": tpr[idx].tolist()}


def confusion_dict(y_true, y_pred) -> dict:
    tn, fp, fn, tp = confusion_matrix(y_true, y_pred).ravel()
    return {"tn": int(tn), "fp": int(fp), "fn": int(fn), "tp": int(tp)}


def feature_importance(pipe, name: str, X_test, y_test) -> pd.DataFrame:
    """Native importance for tree models, |coef| for LR, permutation otherwise."""
    Xt = transformed_frame(pipe, X_test)
    est = pipe[-1]
    if name in TREE_MODELS:
        values = est.feature_importances_
    elif hasattr(est, "coef_"):
        values = np.abs(est.coef_).ravel()
    else:
        from sklearn.inspection import permutation_importance
        values = permutation_importance(
            pipe[-1], Xt, y_test, scoring="f1", n_repeats=3, random_state=42, n_jobs=-1
        ).importances_mean
    out = pd.DataFrame({"Feature": Xt.columns, "Importance": np.asarray(values, float)})
    out["Importance"] = out["Importance"] / out["Importance"].sum()
    return out.sort_values("Importance", ascending=False).reset_index(drop=True)


def cost_benefit(y_true, probs, threshold: float, customer_value: float,
                 offer_cost: float, success_rate: float) -> dict:
    """Simple retention economics at a given probability threshold.

    Contacted customers = predicted churners. Each contact costs ``offer_cost``.
    A contacted true churner is saved with probability ``success_rate`` and
    then retains ``customer_value``. Missed churners (FN) lose ``customer_value``.
    """
    y_true = np.asarray(y_true)
    pred = np.asarray(probs) >= threshold
    tp = int(np.sum(pred & (y_true == 1)))
    fp = int(np.sum(pred & (y_true == 0)))
    fn = int(np.sum(~pred & (y_true == 1)))
    spend = (tp + fp) * offer_cost
    saved_value = tp * success_rate * customer_value
    lost_value = fn * customer_value + tp * (1 - success_rate) * customer_value
    net = saved_value - spend
    baseline_loss = int(np.sum(y_true == 1)) * customer_value  # do nothing
    return {
        "threshold": float(threshold), "contacted": tp + fp, "tp": tp, "fp": fp, "fn": fn,
        "campaign_cost": spend, "revenue_saved": saved_value,
        "net_benefit": net, "residual_loss": lost_value, "baseline_loss": baseline_loss,
        "roi": net / spend if spend else 0.0,
    }


def cost_curve(y_true, probs, customer_value, offer_cost, success_rate,
               thresholds=None) -> pd.DataFrame:
    thresholds = np.linspace(0.05, 0.95, 91) if thresholds is None else thresholds
    return pd.DataFrame([
        cost_benefit(y_true, probs, t, customer_value, offer_cost, success_rate)
        for t in thresholds
    ])
