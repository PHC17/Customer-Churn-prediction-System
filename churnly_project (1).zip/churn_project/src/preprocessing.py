"""Feature engineering, encoding and scaling (Task 10, Task 15).

Encoding choices
----------------
* Subscription Type and Contract Length are ordered -> OrdinalEncoder with an
  explicit order (Basic<Standard<Premium, Monthly<Quarterly<Annual).
* Gender is binary -> a single 0/1 column (Gender_Male), no dummy-variable trap.

Scaling
-------
StandardScaler is applied only for distance/margin/gradient-based models
(Logistic Regression, SVM, KNN). Tree ensembles (Random Forest, XGBoost,
LightGBM) split on thresholds and are invariant to monotonic rescaling, so
they receive raw values, which also keeps SHAP values in original units.
"""
from __future__ import annotations

import numpy as np
import pandas as pd
from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, OrdinalEncoder, StandardScaler

from . import config as C


class FeatureEngineer(BaseEstimator, TransformerMixin):
    """Adds ratio / interaction features. A no-op when ``enabled`` is False."""

    def __init__(self, enabled: bool = False):
        self.enabled = enabled

    def fit(self, X, y=None):
        return self

    def transform(self, X: pd.DataFrame) -> pd.DataFrame:
        if not self.enabled:
            return X
        X = X.copy()
        tenure = X["Tenure"].clip(lower=1)  # guard against division by zero
        X["Spend per Tenure Month"] = X["Total Spend"] / tenure
        X["Calls per Tenure Month"] = X["Support Calls"] / tenure
        X["Delay x Calls"] = X["Payment Delay"] * X["Support Calls"]
        return X


def build_preprocessor(scale: bool, engineered: bool) -> ColumnTransformer:
    """ColumnTransformer for the raw (optionally engineered) feature frame."""
    numeric = C.NUMERIC_FEATURES + (C.ENGINEERED_FEATURES if engineered else [])
    ordinal = OrdinalEncoder(
        categories=[C.SUBSCRIPTION_ORDER, C.CONTRACT_ORDER],
        handle_unknown="error",
    )
    gender = OneHotEncoder(
        categories=[C.GENDER_VALUES], drop="if_binary",
        handle_unknown="error", sparse_output=False,
    )
    return ColumnTransformer(
        [
            ("num", StandardScaler() if scale else "passthrough", numeric),
            ("ord", ordinal, ["Subscription Type", "Contract Length"]),
            ("gen", gender, ["Gender"]),
        ],
        verbose_feature_names_out=False,
    ).set_output(transform="pandas")


def build_pipeline(estimator, scale: bool, engineered: bool = False) -> Pipeline:
    """Full pipeline: feature engineering -> preprocessing -> estimator."""
    return Pipeline(
        [
            ("fe", FeatureEngineer(enabled=engineered)),
            ("prep", build_preprocessor(scale, engineered)),
            ("model", estimator),
        ]
    )


def transformed_frame(pipe: Pipeline, X: pd.DataFrame) -> pd.DataFrame:
    """Apply every step except the final estimator (used for SHAP)."""
    return pipe[:-1].transform(X)


def to_float(X: pd.DataFrame) -> np.ndarray:
    return X.to_numpy(dtype=float)
