"""Central configuration: paths, seeds, schema and business assumptions."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA_PATH = ROOT / "data" / "customer_churn_dataset-testing-master.csv"
ARTIFACT_DIR = ROOT / "artifacts"
MODEL_PATH = ARTIFACT_DIR / "best_model.joblib"
MODEL_HASH_PATH = ARTIFACT_DIR / "best_model.sha256"
REPORT_PATH = ARTIFACT_DIR / "report.json"
TEST_SCORES_PATH = ARTIFACT_DIR / "test_scores.csv"

SEED = 42
TEST_SIZE = 0.20
CV_FOLDS = 5
N_ITER_TUNING = 30

TARGET = "Churn"
ID_COL = "CustomerID"

NUMERIC_FEATURES = [
    "Age", "Tenure", "Usage Frequency", "Support Calls",
    "Payment Delay", "Total Spend", "Last Interaction",
]
ENGINEERED_FEATURES = ["Spend per Tenure Month", "Calls per Tenure Month", "Delay x Calls"]

# Ordered categories: encoded ordinally because there is a natural ordering.
SUBSCRIPTION_ORDER = ["Basic", "Standard", "Premium"]
CONTRACT_ORDER = ["Monthly", "Quarterly", "Annual"]
GENDER_VALUES = ["Female", "Male"]

CATEGORICAL_VALUES = {
    "Gender": GENDER_VALUES,
    "Subscription Type": SUBSCRIPTION_ORDER,
    "Contract Length": CONTRACT_ORDER,
}

# Inclusive bounds used to validate every user-supplied value (form and CSV).
FEATURE_BOUNDS = {
    "Age": (18, 65),
    "Tenure": (1, 60),
    "Usage Frequency": (1, 30),
    "Support Calls": (0, 10),
    "Payment Delay": (0, 30),
    "Total Spend": (100, 1000),
    "Last Interaction": (1, 30),
}
FEATURE_ORDER = [
    "Age", "Gender", "Tenure", "Usage Frequency", "Support Calls", "Payment Delay",
    "Subscription Type", "Contract Length", "Total Spend", "Last Interaction",
]

# Risk bands on churn probability.
RISK_LOW_MAX = 0.35
RISK_HIGH_MIN = 0.65

# Upload safety limits.
MAX_UPLOAD_MB = 10
MAX_UPLOAD_ROWS = 100_000

# Default business assumptions for the cost-benefit simulator (editable in the UI).
DEFAULT_CUSTOMER_VALUE = 500.0   # value of a retained customer (currency units)
DEFAULT_OFFER_COST = 50.0        # cost of one retention intervention
DEFAULT_OFFER_SUCCESS = 0.35     # share of contacted churners who are saved
