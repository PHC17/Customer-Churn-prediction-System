"""Data loading, validation and splitting (Tasks 1-3, 8, 9)."""
from __future__ import annotations

import pandas as pd
from sklearn.model_selection import train_test_split

from . import config as C


def load_raw(path=C.DATA_PATH) -> pd.DataFrame:
    """Load the raw CSV exactly as shipped."""
    return pd.read_csv(path)


def clean(df: pd.DataFrame) -> pd.DataFrame:
    """Return a cleaned copy: strip text, drop duplicate rows, drop missing rows.

    CustomerID is intentionally removed. In this dataset it is a row counter
    sorted by outcome (every ID > 50,000 churned), so keeping it would leak
    the label and produce misleadingly perfect scores.
    """
    out = df.copy()
    for col in C.CATEGORICAL_VALUES:
        out[col] = out[col].astype(str).str.strip().str.title()
    out = out.drop_duplicates().dropna()
    if C.ID_COL in out.columns:
        out = out.drop(columns=C.ID_COL)
    return out.reset_index(drop=True)


def split_xy(df: pd.DataFrame):
    """Separate the feature matrix from the target (Task 8)."""
    return df[C.FEATURE_ORDER].copy(), df[C.TARGET].astype(int)


def train_test(df: pd.DataFrame):
    """Stratified 80/20 split with a fixed seed (Task 9)."""
    X, y = split_xy(df)
    return train_test_split(
        X, y, test_size=C.TEST_SIZE, random_state=C.SEED, stratify=y
    )
