"""Model zoo and hyper-parameter search spaces (Tasks 11, 15, 16)."""
from __future__ import annotations

from lightgbm import LGBMClassifier
from scipy.stats import loguniform, randint, uniform
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.neighbors import KNeighborsClassifier
from sklearn.svm import SVC
from xgboost import XGBClassifier

from . import config as C
from .preprocessing import build_pipeline

# Models that need scaled inputs (distance / margin / gradient based).
NEEDS_SCALING = {
    "Logistic Regression": True,
    "SVM (RBF)": True,
    "KNN": True,
    "Random Forest": False,
    "XGBoost": False,
    "LightGBM": False,
}
TREE_MODELS = {"Random Forest", "XGBoost", "LightGBM"}


def make_estimator(name: str):
    """Fresh, seeded estimator for ``name``."""
    s = C.SEED
    return {
        "Logistic Regression": LogisticRegression(max_iter=2000, random_state=s),
        "Random Forest": RandomForestClassifier(
            n_estimators=300, n_jobs=-1, random_state=s),
        # probability=False keeps SVC training O(n^2) instead of ~5x that;
        # ROC-AUC uses decision_function instead.
        "SVM (RBF)": SVC(kernel="rbf", C=1.0, random_state=s),
        "KNN": KNeighborsClassifier(n_neighbors=15, n_jobs=-1),
        "XGBoost": XGBClassifier(
            n_estimators=300, learning_rate=0.1, max_depth=6,
            eval_metric="logloss", n_jobs=-1, random_state=s),
        "LightGBM": LGBMClassifier(
            n_estimators=300, learning_rate=0.1, n_jobs=-1,
            random_state=s, verbose=-1),
    }[name]


def make_pipeline(name: str, engineered: bool = False):
    return build_pipeline(make_estimator(name), NEEDS_SCALING[name], engineered)


def param_space(name: str) -> dict:
    """RandomizedSearchCV distributions (keys target the 'model' step)."""
    p = "model__"
    spaces = {
        "XGBoost": {
            p + "n_estimators": randint(150, 600),
            p + "max_depth": randint(3, 10),
            p + "learning_rate": loguniform(0.02, 0.3),
            p + "subsample": uniform(0.6, 0.4),
            p + "colsample_bytree": uniform(0.6, 0.4),
            p + "min_child_weight": randint(1, 10),
            p + "reg_lambda": loguniform(0.5, 10),
            p + "gamma": uniform(0, 2),
        },
        "LightGBM": {
            p + "n_estimators": randint(150, 600),
            p + "num_leaves": randint(15, 128),
            p + "learning_rate": loguniform(0.02, 0.3),
            p + "subsample": uniform(0.6, 0.4),
            p + "subsample_freq": [1],
            p + "colsample_bytree": uniform(0.6, 0.4),
            p + "min_child_samples": randint(10, 80),
            p + "reg_lambda": loguniform(0.5, 10),
        },
        "Random Forest": {
            p + "n_estimators": randint(200, 500),
            p + "max_depth": [None, 10, 14, 18, 24],
            p + "min_samples_leaf": randint(1, 10),
            p + "max_features": ["sqrt", "log2", 0.5],
        },
        "Logistic Regression": {p + "C": loguniform(1e-2, 1e2)},
        "KNN": {p + "n_neighbors": randint(5, 40), p + "weights": ["uniform", "distance"]},
        "SVM (RBF)": {p + "C": loguniform(0.1, 10), p + "gamma": ["scale", 0.05, 0.2]},
    }
    return spaces[name]
