"""End-to-end training pipeline. Run:  python -m src.train

Steps: load -> clean -> split -> train 6 baselines -> compare -> best model ->
confusion matrix & importance -> feature engineering -> RandomizedSearchCV with
stratified CV -> threshold analysis -> persist model + JSON report.
"""
from __future__ import annotations

import json
import time

import numpy as np
import pandas as pd
from sklearn.base import clone
from sklearn.model_selection import RandomizedSearchCV, StratifiedKFold, cross_val_score
from sklearn.tree import DecisionTreeClassifier

from . import config as C
from . import data_loader as D
from . import evaluation as E
from . import models as M
from .predictor import save_bundle
from .preprocessing import build_pipeline

MODEL_NAMES = list(M.NEEDS_SCALING)


def log(msg: str) -> None:
    print(f"[{time.strftime('%H:%M:%S')}] {msg}", flush=True)


def main() -> dict:
    np.random.seed(C.SEED)
    raw = D.load_raw()
    df = D.clean(raw)
    log(f"Loaded {len(raw):,} rows -> {len(df):,} after cleaning")
    X_train, X_test, y_train, y_test = D.train_test(df)
    log(f"Train {X_train.shape}  Test {X_test.shape}  churn rate "
        f"train={y_train.mean():.3f} test={y_test.mean():.3f}")

    # ---------------------------------------------------- Task 11-12: baselines
    baseline, fitted, roc, scores_store = [], {}, {}, {}
    for name in MODEL_NAMES:
        t0 = time.time()
        pipe = M.make_pipeline(name).fit(X_train, y_train)
        metrics, scores = E.evaluate(pipe, X_test, y_test)
        fit_s = time.time() - t0
        baseline.append({"Model": name, **metrics, "Fit seconds": fit_s,
                         "Scaled": M.NEEDS_SCALING[name]})
        fitted[name], scores_store[name] = pipe, scores
        roc[name] = E.roc_points(y_test, scores)
        log(f"{name:20s} F1={metrics['F1']:.4f} AUC={metrics['ROC-AUC']:.4f} ({fit_s:.1f}s)")
    base_df = pd.DataFrame(baseline).sort_values("F1", ascending=False)
    best_name = base_df.iloc[0]["Model"]
    log(f"Best baseline by F1: {best_name}")

    # ---------------- Sanity check: how simple is the signal? (leakage / realism)
    # A one-tree model reaching ~99% at modest depth means the labels follow
    # near-deterministic rules (typical of synthetic data), so near-perfect
    # scores here should not be expected on real customer data.
    depth_rows = []
    cv0 = StratifiedKFold(C.CV_FOLDS, shuffle=True, random_state=C.SEED)
    for d in (1, 2, 3, 4, 6, 8, 12):
        tree = build_pipeline(DecisionTreeClassifier(max_depth=d, random_state=C.SEED),
                              scale=False)
        acc = cross_val_score(tree, X_train, y_train, cv=cv0, scoring="accuracy").mean()
        depth_rows.append({"max_depth": d, "cv_accuracy": float(acc)})
    log("Depth check: " + ", ".join(f"d{r['max_depth']}={r['cv_accuracy']:.3f}" for r in depth_rows))

    # --------------------------------------- Task 13-14: confusion + importance
    best_pipe = fitted[best_name]
    base_pred = best_pipe.predict(X_test)
    base_conf = E.confusion_dict(y_test, base_pred)
    importance = {}
    for name in ["Random Forest", "XGBoost", "LightGBM"]:
        importance[name] = E.feature_importance(
            fitted[name], name, X_test, y_test).to_dict("records")

    # ---------------------------------------------- Task 15: feature engineering
    cv = StratifiedKFold(C.CV_FOLDS, shuffle=True, random_state=C.SEED)
    eng_rows = []
    for engineered in (False, True):
        pipe = M.make_pipeline(best_name, engineered)
        cvf1 = cross_val_score(pipe, X_train, y_train, cv=cv, scoring="f1", n_jobs=1)
        pipe.fit(X_train, y_train)
        m, _ = E.evaluate(pipe, X_test, y_test)
        eng_rows.append({"Variant": "With engineered features" if engineered
                         else "Original features",
                         "CV F1 (mean)": cvf1.mean(), "CV F1 (std)": cvf1.std(), **m})
        log(f"{best_name} engineered={engineered} CV-F1={cvf1.mean():.4f} test-F1={m['F1']:.4f}")
    use_eng = eng_rows[1]["CV F1 (mean)"] > eng_rows[0]["CV F1 (mean)"]
    log(f"Feature engineering kept: {use_eng}")

    # ------------------------------------ Task 16: tuning (CV on training only)
    start = M.make_pipeline(best_name, use_eng)
    search = RandomizedSearchCV(
        start, M.param_space(best_name), n_iter=C.N_ITER_TUNING, scoring="f1",
        cv=cv, n_jobs=1, random_state=C.SEED, refit=True, verbose=0)
    t0 = time.time()
    search.fit(X_train, y_train)
    log(f"Tuning done in {time.time() - t0:.0f}s, best CV F1={search.best_score_:.4f}")
    tuned = search.best_estimator_
    tuned_metrics, tuned_scores = E.evaluate(tuned, X_test, y_test)

    # Keep tuned only if it does not hurt CV F1 versus the untuned reference.
    ref_cv = eng_rows[1 if use_eng else 0]["CV F1 (mean)"]
    final_pipe = tuned if search.best_score_ >= ref_cv else clone(start).fit(X_train, y_train)
    final_metrics, final_scores = E.evaluate(final_pipe, X_test, y_test)
    final_pred = (final_scores >= 0.5).astype(int)
    final_conf = E.confusion_dict(y_test, final_pred)
    final_importance = E.feature_importance(final_pipe, best_name, X_test, y_test)

    # --------------------------------------------------- Threshold exploration
    thr_rows = []
    for t in np.linspace(0.1, 0.9, 33):
        m = E.compute_metrics(y_test, (final_scores >= t).astype(int), final_scores)
        thr_rows.append({"threshold": float(t), **m})

    # ----------------------------------------------------------- Persist outputs
    pd.DataFrame({"y_true": y_test.to_numpy(), "score": final_scores}).to_csv(
        C.TEST_SCORES_PATH, index=False)
    save_bundle({
        "pipeline": final_pipe, "name": best_name,
        "engineered": bool(use_eng), "metrics": final_metrics,
        "features": C.FEATURE_ORDER, "seed": C.SEED,
    })
    cv_results = pd.DataFrame(search.cv_results_).sort_values("rank_test_score").head(10)
    report = {
        "n_rows_raw": int(len(raw)), "n_rows_clean": int(len(df)),
        "churn_rate": float(df[C.TARGET].mean()),
        "baseline": base_df.to_dict("records"),
        "best_baseline": best_name,
        "depth_check": depth_rows,
        "baseline_confusion": base_conf,
        "roc": roc,
        "importance": importance,
        "engineering": eng_rows, "use_engineering": bool(use_eng),
        "tuning": {
            "best_params": {k.replace("model__", ""): (v.item() if hasattr(v, "item") else v)
                            for k, v in search.best_params_.items()},
            "best_cv_f1": float(search.best_score_),
            "n_iter": C.N_ITER_TUNING, "cv_folds": C.CV_FOLDS,
            "top_configs": cv_results[["mean_test_score", "std_test_score"]].to_dict("records"),
            "tuned_test_metrics": tuned_metrics, "tuned_kept": bool(final_pipe is tuned),
        },
        "final": {
            "model": best_name, "metrics": final_metrics, "confusion": final_conf,
            "importance": final_importance.to_dict("records"),
            "roc": E.roc_points(y_test, final_scores),
        },
        "thresholds": thr_rows,
    }
    C.REPORT_PATH.write_text(json.dumps(report, indent=2, default=float))
    log(f"FINAL {best_name}: " + "  ".join(f"{k}={v:.4f}" for k, v in final_metrics.items()))
    return report


if __name__ == "__main__":
    main()
