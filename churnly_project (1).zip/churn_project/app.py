"""Churnly - Customer Churn Intelligence dashboard (Streamlit).

Run:  streamlit run app.py
"""
from __future__ import annotations

import io
import json

import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st

from src import config as C
from src import data_loader as D
from src import evaluation as E
from src import predictor as P

st.set_page_config(page_title="Churnly | Churn Intelligence", page_icon="📉",
                   layout="wide", initial_sidebar_state="expanded")

# --------------------------------------------------------------------- theme
BLUE, BLUE_D, BLUE_L = "#2563EB", "#1E3A8A", "#93C5FD"
CORAL, TEAL = "#F97362", "#14B8A6"
RISK_COLORS = {"Low": "#16A34A", "Medium": "#F59E0B", "High": "#DC2626"}
RISK_BG = {"Low": "#ECFDF3", "Medium": "#FFF8E6", "High": "#FEF0EF"}

CSS = """
<style>
html, body, [class*="css"] { font-family: 'Inter', 'Segoe UI', system-ui, sans-serif; }
.block-container { padding-top: 1.6rem; padding-bottom: 3rem; max-width: 1280px; }
h1, h2, h3 { color: #1E3A8A; letter-spacing: -0.01em; }
section[data-testid="stSidebar"] { background: #FFFFFF; border-right: 1px solid #E2E8F0; }
.brand { font-size: 1.35rem; font-weight: 800; color: #1E3A8A; margin-bottom: .1rem; }
.brand span { color: #2563EB; }
.tagline { color: #64748B; font-size: .82rem; margin-bottom: 1rem; }
.card { background: #FFFFFF; border: 1px solid #E2E8F0; border-radius: 14px;
        padding: 1.05rem 1.2rem; box-shadow: 0 1px 2px rgba(15,23,42,.04); height: 100%; }
.kpi-label { color: #64748B; font-size: .78rem; text-transform: uppercase;
             letter-spacing: .06em; font-weight: 600; }
.kpi-value { color: #1E3A8A; font-size: 1.85rem; font-weight: 800; line-height: 1.15; }
.kpi-sub { color: #94A3B8; font-size: .8rem; }
.page-sub { color: #64748B; margin-top: -.6rem; margin-bottom: 1.2rem; }
.result { border-radius: 16px; padding: 1.4rem 1.6rem; border: 1px solid; }
.result .tag { font-size: .8rem; font-weight: 700; text-transform: uppercase; letter-spacing: .08em; }
.result .big { font-size: 2.6rem; font-weight: 800; line-height: 1.1; }
.result .verdict { font-size: 1.05rem; font-weight: 600; margin-top: .2rem; }
.pill { display: inline-block; padding: .15rem .6rem; border-radius: 999px; font-size: .75rem;
        font-weight: 700; }
.note { background: #EFF6FF; border-left: 4px solid #2563EB; border-radius: 8px;
        padding: .8rem 1rem; color: #1E3A8A; font-size: .92rem; }
.warn { background: #FFF8E6; border-left: 4px solid #F59E0B; border-radius: 8px;
        padding: .8rem 1rem; color: #7A4B00; font-size: .92rem; }
.rec { background: #FFFFFF; border: 1px solid #E2E8F0; border-radius: 12px;
       padding: .75rem 1rem; margin-bottom: .55rem; }
.rec b { color: #1E3A8A; }
div[data-testid="stMetric"] { background: #fff; border: 1px solid #E2E8F0; border-radius: 12px;
        padding: .6rem .9rem; }
.stButton > button, .stDownloadButton > button { border-radius: 10px; font-weight: 600; }
</style>
"""
st.markdown(CSS, unsafe_allow_html=True)


def style_fig(fig: go.Figure, height: int = 380) -> go.Figure:
    fig.update_layout(
        template="plotly_white", height=height, margin=dict(l=10, r=10, t=50, b=10),
        font=dict(family="Inter, Segoe UI, sans-serif", size=13, color="#0F172A"),
        title=dict(font=dict(size=16, color=BLUE_D), x=0.01),
        paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
        legend=dict(orientation="h", y=-0.18),
    )
    fig.update_xaxes(gridcolor="#EEF2F7", zerolinecolor="#E2E8F0")
    fig.update_yaxes(gridcolor="#EEF2F7", zerolinecolor="#E2E8F0")
    return fig


def show(fig: go.Figure, height: int = 380) -> None:
    st.plotly_chart(style_fig(fig, height), width="stretch")


def kpi(label: str, value: str, sub: str = "") -> str:
    """Static HTML KPI card. Only ever called with app-computed strings."""
    return (f'<div class="card"><div class="kpi-label">{label}</div>'
            f'<div class="kpi-value">{value}</div><div class="kpi-sub">{sub}</div></div>')


def header(title: str, sub: str) -> None:
    st.markdown(f"# {title}")
    st.markdown(f'<div class="page-sub">{sub}</div>', unsafe_allow_html=True)


# ------------------------------------------------------------------- loaders
@st.cache_data(show_spinner=False)
def load_data():
    raw = D.load_raw()
    return raw, D.clean(raw)


@st.cache_data(show_spinner=False)
def load_report() -> dict:
    return json.loads(C.REPORT_PATH.read_text())


@st.cache_resource(show_spinner=False)
def load_model():
    return P.load_bundle()


@st.cache_data(show_spinner="Scoring held-out customers...")
def holdout_scores():
    """Re-create the deterministic 80/20 split and score the 20% test set."""
    _, clean = load_data()
    _, X_test, _, y_test = D.train_test(clean)
    probs = load_model()["pipeline"].predict_proba(X_test)[:, 1]
    out = X_test.reset_index(drop=True).copy()
    out["Churn Probability"] = probs
    out["Actual Churn"] = y_test.to_numpy()
    out["Risk"] = [P.risk_category(p) for p in probs]
    return out


try:
    RAW, DF = load_data()
    REPORT = load_report()
    BUNDLE = load_model()
except FileNotFoundError:
    st.error("Model artifacts not found. Run `python -m src.train` once, then reload this page.")
    st.stop()
except Exception as exc:  # integrity failure, corrupt file, etc.
    st.error(f"Could not load the model or data: {exc}")
    st.stop()

# ------------------------------------------------------------------- sidebar
PAGES = ["Overview", "Data Explorer", "Model Performance", "Feature Importance",
         "Predict", "Batch Scoring", "Business Impact", "Customer Risk Analysis"]
with st.sidebar:
    st.markdown('<div class="brand">Churn<span>ly</span></div>'
                '<div class="tagline">Customer churn intelligence</div>', unsafe_allow_html=True)
    page = st.radio("Navigate", PAGES, label_visibility="collapsed")
    st.divider()
    threshold = st.slider("Decision threshold", 0.05, 0.95, 0.50, 0.05,
                          help="Customers with churn probability at or above this value are "
                               "flagged as churners. Lower = catch more churners, more false alarms.")
    st.caption(f"Model: **{BUNDLE['name']}** (tuned)")
    st.caption(f"Test F1 {BUNDLE['metrics']['F1']:.4f} | AUC {BUNDLE['metrics']['ROC-AUC']:.4f}")


# ===================================================================== pages
def page_overview():
    header("Overview", "Portfolio health and model-based risk at a glance.")
    hold = holdout_scores()
    total, churn_rate = len(DF), DF[C.TARGET].mean()
    flagged = (hold["Churn Probability"] >= threshold).mean()
    cols = st.columns(5)
    items = [
        ("Customers", f"{total:,}", "after cleaning"),
        ("Churn rate", f"{churn_rate:.1%}", f"{int(DF[C.TARGET].sum()):,} churned"),
        ("Avg tenure", f"{DF['Tenure'].mean():.1f} mo", "months with us"),
        ("Avg spend", f"{DF['Total Spend'].mean():,.0f}", "total per customer"),
        ("Flagged at risk", f"{flagged:.1%}", f"threshold {threshold:.2f} (held-out set)"),
    ]
    for col, (a, b, c) in zip(cols, items):
        col.markdown(kpi(a, b, c), unsafe_allow_html=True)
    st.write("")

    c1, c2 = st.columns([1.1, 1])
    with c1:
        counts = hold["Risk"].value_counts().reindex(["Low", "Medium", "High"]).fillna(0)
        fig = go.Figure(go.Bar(x=counts.index, y=counts.values,
                               marker_color=[RISK_COLORS[r] for r in counts.index],
                               text=[f"{int(v):,}" for v in counts.values], textposition="outside"))
        fig.update_layout(title="Risk distribution (held-out customers)", yaxis_title="Customers")
        show(fig)
    with c2:
        g = DF.groupby("Contract Length")[C.TARGET].mean().reindex(C.CONTRACT_ORDER) * 100
        fig = px.bar(x=g.index, y=g.values, labels={"x": "Contract", "y": "Churn rate (%)"},
                     color_discrete_sequence=[BLUE], text=[f"{v:.0f}%" for v in g.values])
        fig.update_layout(title="Churn rate by contract length")
        fig.update_traces(textposition="outside")
        show(fig)

    st.markdown(
        '<div class="warn"><b>Read this before trusting the scores.</b> A single depth-8 decision '
        'tree already reaches ~99% accuracy on this file, and the boosted models score ~100%. '
        'That is a property of this dataset (its labels follow near-deterministic rules, typical of '
        'synthetic data), not a promise of real-world accuracy. See <i>Model Performance</i> for the '
        'evidence. Re-validate on your own production data before acting on probabilities.</div>',
        unsafe_allow_html=True)


def page_explorer():
    header("Data Explorer", "How customer behaviour relates to churn.")
    num_cols = C.NUMERIC_FEATURES
    cat_cols = list(C.CATEGORICAL_VALUES)
    tab1, tab2, tab3, tab4 = st.tabs(["Distributions", "Churn drivers", "Correlations", "Leakage audit"])

    with tab1:
        feat = st.selectbox("Numeric feature", num_cols, index=num_cols.index("Payment Delay"))
        d = DF.assign(Status=DF[C.TARGET].map({0: "Stayed", 1: "Churned"}))
        fig = px.histogram(d, x=feat, color="Status", barmode="overlay", nbins=30, opacity=0.7,
                           color_discrete_map={"Stayed": BLUE, "Churned": CORAL})
        fig.update_layout(title=f"{feat} distribution by outcome")
        show(fig)
        fig = px.box(d, x="Status", y=feat, color="Status",
                     color_discrete_map={"Stayed": BLUE, "Churned": CORAL})
        fig.update_layout(title=f"{feat} spread by outcome", showlegend=False)
        show(fig, 320)

    with tab2:
        c1, c2 = st.columns(2)
        with c1:
            bins = {"Support Calls": None, "Payment Delay": [0, 5, 10, 15, 20, 25, 30],
                    "Tenure": [0, 12, 24, 36, 48, 60], "Usage Frequency": [0, 5, 10, 15, 20, 25, 30],
                    "Age": [17, 25, 35, 45, 55, 65], "Total Spend": [99, 300, 500, 700, 1000],
                    "Last Interaction": [0, 5, 10, 15, 20, 25, 30]}
            f = st.selectbox("Churn rate by", list(bins), key="drv")
            s = DF[f] if bins[f] is None else pd.cut(DF[f], bins[f], include_lowest=True).astype(str)
            g = DF.groupby(s)[C.TARGET].agg(["mean", "count"]).reset_index()
            g.columns = [f, "Churn rate", "Customers"]
            if bins[f] is not None:  # keep bins in numeric order
                g["_o"] = g[f].str.extract(r"([\d.]+)").astype(float)
                g = g.sort_values("_o").drop(columns="_o")
            fig = px.bar(g, x=f, y="Churn rate", color_discrete_sequence=[BLUE],
                         hover_data=["Customers"])
            fig.update_yaxes(tickformat=".0%")
            fig.update_layout(title=f"Churn rate by {f}")
            show(fig)
        with c2:
            c = st.selectbox("Category", cat_cols, key="cat")
            order = C.CATEGORICAL_VALUES[c]
            g = DF.groupby(c)[C.TARGET].mean().reindex(order).reset_index()
            fig = px.bar(g, x=c, y=C.TARGET, color_discrete_sequence=[TEAL],
                         labels={C.TARGET: "Churn rate"})
            fig.update_yaxes(tickformat=".0%")
            fig.update_layout(title=f"Churn rate by {c}")
            show(fig)
        heat = DF.assign(**{"Support Calls (5+)": np.where(DF["Support Calls"] >= 5, "5+", "0-4"),
                            "Payment Delay": np.where(DF["Payment Delay"] > 15, ">15 days", "<=15 days")}
                         ).pivot_table(index="Support Calls (5+)", columns="Payment Delay",
                                       values=C.TARGET, aggfunc="mean")
        fig = px.imshow(heat, text_auto=".0%", color_continuous_scale="Blues", aspect="auto")
        fig.update_layout(title="Compounding risk: support calls x payment delay")
        show(fig, 300)
        st.markdown('<div class="note">Churn jumps from ~24% to ~61% at 5+ support calls and from ~10% '
                    'to 59-77% beyond a 15-day payment delay. Customers with both exceed 80%.</div>',
                    unsafe_allow_html=True)

    with tab3:
        enc = DF.copy()
        enc["Gender"] = (enc["Gender"] == "Male").astype(int)
        enc["Subscription Type"] = enc["Subscription Type"].map({k: i for i, k in enumerate(C.SUBSCRIPTION_ORDER)})
        enc["Contract Length"] = enc["Contract Length"].map({k: i for i, k in enumerate(C.CONTRACT_ORDER)})
        corr = enc.corr()
        fig = px.imshow(corr, text_auto=".2f", color_continuous_scale="RdBu_r", zmin=-1, zmax=1, aspect="auto")
        fig.update_layout(title="Correlation matrix (encoded features)")
        show(fig, 560)

    with tab4:
        g = RAW.assign(Bucket=(RAW[C.ID_COL] - 1) // 10000 * 10000 + 1).groupby("Bucket")[C.TARGET].mean()
        fig = px.bar(x=[f"{int(b):,}+" for b in g.index], y=g.values, color_discrete_sequence=[CORAL],
                     labels={"x": "CustomerID range", "y": "Churn rate"})
        fig.update_yaxes(tickformat=".0%")
        fig.update_layout(title="Why CustomerID was removed: churn rate by ID range")
        show(fig, 320)
        st.markdown('<div class="note">The raw file is sorted by outcome: every customer with ID above '
                    '50,000 churned. Keeping CustomerID would leak the label, so it is dropped before '
                    'training (as the brief also requires).</div>', unsafe_allow_html=True)


def page_models():
    header("Model Performance", "Six models, one held-out test set (20%, stratified, seed 42).")
    base = pd.DataFrame(REPORT["baseline"])
    metrics = ["Accuracy", "Precision", "Recall", "F1", "ROC-AUC"]
    st.subheader("Model comparison")
    show_df = base[["Model", *metrics, "Fit seconds", "Scaled"]].sort_values("F1", ascending=False)
    st.dataframe(show_df.style.format({m: "{:.4f}" for m in metrics} | {"Fit seconds": "{:.1f}"})
                 .highlight_max(subset=metrics, color="#DBEAFE"),
                 width="stretch", hide_index=True)
    st.caption("Scaled = StandardScaler applied. Logistic Regression, SVM and KNN are distance/margin "
               "based and need scaling; tree ensembles do not. Selection metric: F1 (balances catching "
               "churners with not wasting offers).")

    c1, c2 = st.columns(2)
    with c1:
        fig = go.Figure()
        for m, color in zip(["Precision", "Recall", "F1"], [BLUE_L, TEAL, BLUE_D]):
            fig.add_bar(name=m, x=base["Model"], y=base[m], marker_color=color)
        fig.update_layout(barmode="group", title="Precision / Recall / F1 by model")
        fig.update_yaxes(range=[0.7, 1.01])
        show(fig)
    with c2:
        fig = go.Figure()
        palette = [BLUE_D, BLUE, TEAL, "#8B5CF6", CORAL, "#F59E0B"]
        for (name, pts), color in zip(REPORT["roc"].items(), palette):
            auc = base.loc[base.Model == name, "ROC-AUC"].iloc[0]
            fig.add_scatter(x=pts["fpr"], y=pts["tpr"], mode="lines", name=f"{name} ({auc:.3f})",
                            line=dict(color=color, width=2.2))
        fig.add_scatter(x=[0, 1], y=[0, 1], mode="lines", line=dict(dash="dash", color="#94A3B8"),
                        name="Chance", showlegend=False)
        fig.update_layout(title="ROC curves", xaxis_title="False positive rate",
                          yaxis_title="True positive rate")
        show(fig)

    st.subheader(f"Final model: {REPORT['final']['model']}")
    fm = REPORT["final"]["metrics"]
    cols = st.columns(5)
    for col, m in zip(cols, metrics):
        col.metric(m, f"{fm[m]:.4f}")

    cm = REPORT["final"]["confusion"]
    c1, c2 = st.columns([1, 1.1])
    with c1:
        z = [[cm["tn"], cm["fp"]], [cm["fn"], cm["tp"]]]
        fig = px.imshow(z, text_auto=",", x=["Pred: Stay", "Pred: Churn"], y=["Actual: Stay", "Actual: Churn"],
                        color_continuous_scale="Blues", aspect="auto")
        fig.update_layout(title="Confusion matrix (threshold 0.50)", coloraxis_showscale=False)
        show(fig, 340)
    with c2:
        st.markdown(f"""
**False positives ({cm['fp']}):** loyal customers we would contact needlessly. Cost: one retention offer
(plus a small risk of training customers to expect discounts).

**False negatives ({cm['fn']}):** churners we miss. Cost: the full lifetime value of the customer, typically
**several times** the price of an offer. This is why recall is weighted heavily and why the threshold slider
in the sidebar lets you trade precision for recall.

With a 10:1 value-to-offer ratio, a missed churner is worth about ten wasted offers, so the optimal
threshold sits below 0.50 whenever the model is uncertain. See *Business Impact*.
""")

    st.subheader("How the model was improved")
    eng = pd.DataFrame(REPORT["engineering"])
    tun = REPORT["tuning"]
    c1, c2 = st.columns(2)
    with c1:
        st.markdown("**Feature engineering** (CV on training set, 5-fold)")
        st.dataframe(eng[["Variant", "CV F1 (mean)", "CV F1 (std)", "F1", "ROC-AUC"]].style.format(
            {c: "{:.4f}" for c in ["CV F1 (mean)", "CV F1 (std)", "F1", "ROC-AUC"]}),
            width="stretch", hide_index=True)
        st.caption("Added spend/tenure, calls/tenure and delay x calls. Kept only if CV F1 improved: "
                   + ("kept." if REPORT["use_engineering"] else "not kept (no gain)."))
    with c2:
        st.markdown(f"**RandomizedSearchCV** ({tun['n_iter']} candidates x {tun['cv_folds']}-fold CV)")
        b = base.loc[base.Model == REPORT["best_baseline"], metrics].iloc[0]
        t = tun["tuned_test_metrics"]
        cmp = pd.DataFrame({"Baseline": b.values, "Tuned": [t[m] for m in metrics]},
                           index=metrics)
        cmp["Change"] = cmp["Tuned"] - cmp["Baseline"]
        st.dataframe(cmp.style.format("{:+.4f}", subset=["Change"]).format("{:.4f}", subset=["Baseline", "Tuned"]),
                     width="stretch")
        st.caption(f"Best CV F1: {tun['best_cv_f1']:.4f}. Tuned model used: {tun['tuned_kept']}. "
                   "Differences are a handful of customers, i.e. noise: the baseline was already at the ceiling.")

    st.subheader("Why the scores are this high")
    depth = pd.DataFrame(REPORT.get("depth_check", []))
    if not depth.empty:
        fig = px.line(depth, x="max_depth", y="cv_accuracy", markers=True,
                      color_discrete_sequence=[BLUE_D], labels={"cv_accuracy": "CV accuracy", "max_depth": "Tree depth"})
        fig.update_yaxes(tickformat=".0%")
        fig.update_layout(title="A single decision tree: accuracy vs depth")
        show(fig, 320)
    st.markdown('<div class="warn">One shallow tree recovers almost all of the signal and no two customers '
                'have identical features with different outcomes. The labels in this file follow '
                'near-deterministic rules (typical of synthetic data). Expect materially lower metrics '
                'on real customer data.</div>', unsafe_allow_html=True)


def page_importance():
    header("Feature Importance", "What the models rely on, compared with what the EDA suggested.")
    options = {"Final tuned model": REPORT["final"]["importance"], **REPORT["importance"]}
    choice = st.selectbox("Model", list(options))
    imp = pd.DataFrame(options[choice]).sort_values("Importance")
    fig = px.bar(imp, x="Importance", y="Feature", orientation="h", color_discrete_sequence=[BLUE])
    fig.update_xaxes(tickformat=".0%")
    fig.update_layout(title=f"Feature importance: {choice}")
    show(fig, 440)

    enc = DF.copy()
    enc["Gender"] = (enc["Gender"] == "Male").astype(int)
    enc["Subscription Type"] = enc["Subscription Type"].map({k: i for i, k in enumerate(C.SUBSCRIPTION_ORDER)})
    enc["Contract Length"] = enc["Contract Length"].map({k: i for i, k in enumerate(C.CONTRACT_ORDER)})
    corr = enc.corr()[C.TARGET].drop(C.TARGET).abs()
    name_map = {"Gender": "Gender_Male"}
    cmp = pd.DataFrame({"Feature": corr.index, "|Correlation| with churn": corr.values})
    imp_lookup = pd.DataFrame(options[choice]).set_index("Feature")["Importance"]
    cmp["Model importance"] = [imp_lookup.get(name_map.get(f, f), np.nan) for f in cmp["Feature"]]
    cmp = cmp.sort_values("Model importance", ascending=False)
    st.markdown("**EDA vs model**")
    st.dataframe(cmp.style.format({"|Correlation| with churn": "{:.3f}", "Model importance": "{:.1%}"}),
                 width="stretch", hide_index=True)
    st.markdown('<div class="note">Payment delay and support calls are top-three in both views, and Last Interaction and Subscription Type are weak in both. Gender, Usage Frequency and Age rank higher in the model than by linear correlation because their effects are <b>thresholds or interactions</b> (e.g. usage of 5 or fewer) that Pearson correlation cannot see; Tenure ranks lower.</div>', unsafe_allow_html=True)


def _form_defaults():
    return {"Age": 40, "Gender": "Female", "Tenure": 24, "Usage Frequency": 15, "Support Calls": 2,
            "Payment Delay": 5, "Subscription Type": "Standard", "Contract Length": "Annual",
            "Total Spend": 600, "Last Interaction": 10}


PRESETS = {
    "Custom": None,
    "Loyal customer": {"Age": 38, "Gender": "Male", "Tenure": 18, "Usage Frequency": 22, "Support Calls": 1,
                       "Payment Delay": 4, "Subscription Type": "Premium", "Contract Length": "Annual",
                       "Total Spend": 820, "Last Interaction": 6},
    "Borderline customer": {"Age": 52, "Gender": "Female", "Tenure": 30, "Usage Frequency": 4, "Support Calls": 3,
                            "Payment Delay": 12, "Subscription Type": "Basic", "Contract Length": "Monthly",
                            "Total Spend": 280, "Last Interaction": 14},
    "At-risk customer": {"Age": 55, "Gender": "Female", "Tenure": 40, "Usage Frequency": 3, "Support Calls": 8,
                         "Payment Delay": 24, "Subscription Type": "Basic", "Contract Length": "Monthly",
                         "Total Spend": 210, "Last Interaction": 25},
}


def _apply_preset():
    p = PRESETS.get(st.session_state.get("preset"))
    if p:
        for k, v in p.items():
            st.session_state[f"f_{k}"] = v


def risk_card(prob: float, label: str, risk: str) -> None:
    color, bg = RISK_COLORS[risk], RISK_BG[risk]
    verdict = "Likely to churn" if label == "Yes" else "Likely to stay"
    st.markdown(
        f'<div class="result" style="background:{bg};border-color:{color}55;">'
        f'<div class="tag" style="color:{color};">{risk} risk</div>'
        f'<div class="big" style="color:{color};">{prob:.1%}</div>'
        f'<div class="verdict" style="color:#0F172A;">{verdict} &middot; churn prediction: <b>{label}</b></div>'
        f'<div class="kpi-sub">Threshold {threshold:.2f}</div></div>', unsafe_allow_html=True)


def gauge(prob: float, risk: str) -> go.Figure:
    fig = go.Figure(go.Indicator(
        mode="gauge", value=prob * 100,
        gauge=dict(axis=dict(range=[0, 100], ticksuffix="%"), bar=dict(color=RISK_COLORS[risk], thickness=0.3),
                   steps=[dict(range=[0, C.RISK_LOW_MAX * 100], color=RISK_BG["Low"]),
                          dict(range=[C.RISK_LOW_MAX * 100, C.RISK_HIGH_MIN * 100], color=RISK_BG["Medium"]),
                          dict(range=[C.RISK_HIGH_MIN * 100, 100], color=RISK_BG["High"])])))
    return style_fig(fig, 220)


def render_recommendations(row: dict, risk: str) -> None:
    rec = P.recommendations(row, risk)
    st.markdown("#### Retention plan")
    st.markdown(f'<div class="note">{rec["headline"]}</div>', unsafe_allow_html=True)
    st.write("")
    if risk == "Low" and not rec["factors"]:
        st.success("No elevated risk factors detected.")
    for f in rec["factors"]:
        st.markdown(f'<div class="rec"><b>{f["factor"]}</b><br>{f["action"]}</div>', unsafe_allow_html=True)


def render_shap(row: dict) -> None:
    try:
        with st.spinner("Computing SHAP explanation..."):
            sh = P.shap_explain(BUNDLE, row)
    except Exception as exc:
        st.info(f"SHAP explanation unavailable: {exc}")
        return
    if sh is None:
        st.info("SHAP is available for tree-based models only.")
        return
    sh = sh.iloc[::-1]
    labels = [f"{f} = {v:g}" for f, v in zip(sh["Feature"], sh["Value"])]
    fig = go.Figure(go.Bar(x=sh["SHAP"], y=labels, orientation="h",
                           marker_color=[CORAL if v > 0 else BLUE for v in sh["SHAP"]]))
    fig.update_layout(title="Why this score? SHAP contributions (log-odds)",
                      xaxis_title="Pushes toward stay  <-  0  ->  pushes toward churn")
    show(fig, 400)


def page_predict():
    header("Live Prediction", "Adjust the customer profile; the result updates instantly.")
    d = _form_defaults()
    for k, v in d.items():
        st.session_state.setdefault(f"f_{k}", v)
    st.selectbox("Start from a preset", list(PRESETS), key="preset", on_change=_apply_preset)

    left, right = st.columns([1, 1.15], gap="large")
    row = {}
    with left:
        st.markdown("#### Customer profile")
        a, b = st.columns(2)
        row["Age"] = a.slider("Age", *C.FEATURE_BOUNDS["Age"], key="f_Age")
        row["Gender"] = b.selectbox("Gender", C.GENDER_VALUES, key="f_Gender")
        row["Tenure"] = a.slider("Tenure (months)", *C.FEATURE_BOUNDS["Tenure"], key="f_Tenure")
        row["Usage Frequency"] = b.slider("Usage frequency", *C.FEATURE_BOUNDS["Usage Frequency"], key="f_Usage Frequency")
        row["Support Calls"] = a.slider("Support calls", *C.FEATURE_BOUNDS["Support Calls"], key="f_Support Calls")
        row["Payment Delay"] = b.slider("Payment delay (days)", *C.FEATURE_BOUNDS["Payment Delay"], key="f_Payment Delay")
        row["Subscription Type"] = a.selectbox("Subscription", C.SUBSCRIPTION_ORDER, key="f_Subscription Type")
        row["Contract Length"] = b.selectbox("Contract", C.CONTRACT_ORDER, key="f_Contract Length")
        row["Total Spend"] = a.slider("Total spend", *C.FEATURE_BOUNDS["Total Spend"], key="f_Total Spend")
        row["Last Interaction"] = b.slider("Days since last interaction", *C.FEATURE_BOUNDS["Last Interaction"],
                                           key="f_Last Interaction")
    with right:
        try:
            res = P.predict_one(BUNDLE, row, threshold)
        except ValueError as exc:
            st.error(f"Invalid input: {exc}")
            return
        except Exception as exc:
            st.error(f"Prediction failed: {exc}")
            return
        risk_card(res["probability"], res["prediction"], res["risk"])
        st.plotly_chart(gauge(res["probability"], res["risk"]), width="stretch")
        render_recommendations(row, res["risk"])
    st.divider()
    if st.toggle("Explain this prediction (SHAP)", value=True):
        render_shap(row)


def _csv_safe(df: pd.DataFrame) -> pd.DataFrame:
    """Neutralise spreadsheet formula injection in text cells before export."""
    out = df.copy()
    for col in out.columns:
        if pd.api.types.is_string_dtype(out[col]) or out[col].dtype == object:
            out[col] = out[col].astype(str).map(
                lambda s: "'" + s if s[:1] in ("=", "+", "-", "@", "\t", "\r") else s)
    return out


def page_batch():
    header("Batch Scoring", "Upload a CSV of customers and download scored results.")
    template = pd.DataFrame([_form_defaults(), PRESETS["At-risk customer"]])
    st.download_button("Download CSV template", template.to_csv(index=False).encode(),
                       "churn_template.csv", "text/csv")
    st.caption(f"Required columns: {', '.join(C.FEATURE_ORDER)}. Optional: CustomerID (passed through). "
               f"Limits: {C.MAX_UPLOAD_MB} MB, {C.MAX_UPLOAD_ROWS:,} rows.")
    up = st.file_uploader("Upload CSV", type=["csv"], accept_multiple_files=False)
    if up is None:
        return
    if up.size > C.MAX_UPLOAD_MB * 1024 * 1024:
        st.error(f"File is larger than {C.MAX_UPLOAD_MB} MB.")
        return
    try:
        raw = pd.read_csv(up, nrows=C.MAX_UPLOAD_ROWS + 1)
    except (pd.errors.ParserError, pd.errors.EmptyDataError, UnicodeDecodeError) as exc:
        st.error(f"Could not read the file as CSV: {exc}")
        return
    if raw.empty:
        st.error("The file has no rows.")
        return
    if len(raw) > C.MAX_UPLOAD_ROWS:
        st.error(f"Too many rows (limit {C.MAX_UPLOAD_ROWS:,}).")
        return
    try:
        with st.spinner(f"Scoring {len(raw):,} customers..."):
            out = P.predict_frame(BUNDLE, raw, threshold)
    except ValueError as exc:
        st.error(f"Validation failed: {exc}")
        return
    except Exception as exc:
        st.error(f"Scoring failed: {exc}")
        return
    if C.ID_COL in raw.columns:
        out.insert(0, C.ID_COL, raw[C.ID_COL].astype(str).str[:64].to_numpy())
    st.success(f"Scored {len(out):,} customers.")
    c = st.columns(4)
    c[0].metric("Customers", f"{len(out):,}")
    c[1].metric("Predicted churners", f"{(out['Prediction'] == 'Yes').sum():,}")
    c[2].metric("Avg probability", f"{out['Churn Probability'].mean():.1%}")
    c[3].metric("High risk", f"{(out['Risk'] == 'High').sum():,}")
    counts = out["Risk"].value_counts().reindex(["Low", "Medium", "High"]).fillna(0)
    fig = go.Figure(go.Bar(x=counts.index, y=counts.values, marker_color=[RISK_COLORS[r] for r in counts.index]))
    fig.update_layout(title="Risk distribution of uploaded customers")
    show(fig, 300)
    view = out.sort_values("Churn Probability", ascending=False)
    st.dataframe(view.head(500).style.format({"Churn Probability": "{:.1%}"}), width="stretch", hide_index=True)
    st.download_button("Download scored CSV", _csv_safe(view).to_csv(index=False).encode(),
                       "churn_scored.csv", "text/csv")


def page_business():
    header("Business Impact", "Is a retention campaign worth it, and where should the threshold sit?")
    hold = holdout_scores()
    c1, c2, c3 = st.columns(3)
    value = c1.number_input("Value of a retained customer", 1.0, 1e6, C.DEFAULT_CUSTOMER_VALUE, 50.0)
    cost = c2.number_input("Cost per retention offer", 0.0, 1e5, C.DEFAULT_OFFER_COST, 5.0)
    success = c3.slider("Offer success rate", 0.05, 1.0, C.DEFAULT_OFFER_SUCCESS, 0.05)
    y, p = hold["Actual Churn"].to_numpy(), hold["Churn Probability"].to_numpy()
    cur = E.cost_benefit(y, p, threshold, value, cost, success)
    curve = E.cost_curve(y, p, value, cost, success)
    best = curve.loc[curve["net_benefit"].idxmax()]
    everyone = E.cost_benefit(y, np.ones_like(p), 0.5, value, cost, success)

    k = st.columns(4)
    k[0].metric("Customers contacted", f"{cur['contacted']:,}")
    k[1].metric("Campaign cost", f"{cur['campaign_cost']:,.0f}")
    k[2].metric("Revenue saved", f"{cur['revenue_saved']:,.0f}")
    k[3].metric("Net benefit", f"{cur['net_benefit']:,.0f}", f"ROI {cur['roi']:.1f}x")

    fig = go.Figure()
    fig.add_scatter(x=curve["threshold"], y=curve["net_benefit"], mode="lines", name="Model-targeted",
                    line=dict(color=BLUE, width=3))
    fig.add_hline(y=everyone["net_benefit"], line_dash="dash", line_color=CORAL,
                  annotation_text="Contact everyone", annotation_position="bottom right")
    fig.add_hline(y=0, line_color="#94A3B8", annotation_text="Do nothing", annotation_position="top right")
    fig.add_vline(x=threshold, line_dash="dot", line_color=BLUE_D, annotation_text="current")
    fig.update_layout(title="Net benefit vs decision threshold (held-out customers)",
                      xaxis_title="Threshold", yaxis_title="Net benefit")
    show(fig)
    st.markdown(f'<div class="note">Best threshold on this data: <b>{best["threshold"]:.2f}</b> '
                f'(net benefit {best["net_benefit"]:,.0f}). Targeting with the model beats contacting everyone by '
                f'<b>{best["net_benefit"] - everyone["net_benefit"]:,.0f}</b> because offers are not wasted on loyal '
                f'customers. Because the model is near-perfect on this dataset the curve is flat across a wide '
                f'range; on real data it will peak more sharply and usually sits below 0.5 when '
                f'value &gt; offer cost.</div>', unsafe_allow_html=True)
    st.caption("Assumptions: a contacted churner is saved with the chosen success rate; missed churners lose the full "
               "customer value; all contacted customers incur the offer cost. Simplified, illustrative economics.")


def page_samples():
    header("Customer Risk Analysis", "Drill into individual held-out customers.")
    hold = holdout_scores()
    pick = st.radio("Show", ["Highest risk", "Lowest risk", "Random sample"], horizontal=True)
    if pick == "Highest risk":
        view = hold.sort_values("Churn Probability", ascending=False).head(25)
    elif pick == "Lowest risk":
        view = hold.sort_values("Churn Probability").head(25)
    else:
        view = hold.sample(25, random_state=C.SEED).sort_values("Churn Probability", ascending=False)
    st.dataframe(view.style.format({"Churn Probability": "{:.1%}"}), width="stretch")
    idx = st.selectbox("Inspect customer (row index in held-out set)", view.index.tolist())
    r = hold.loc[idx]
    row = {k: (r[k].item() if hasattr(r[k], "item") else r[k]) for k in C.FEATURE_ORDER}
    res = P.predict_one(BUNDLE, row, threshold)
    a, b = st.columns([1, 1.2], gap="large")
    with a:
        risk_card(res["probability"], res["prediction"], res["risk"])
        st.caption(f"Actual outcome: **{'Churned' if r['Actual Churn'] == 1 else 'Stayed'}**")
        render_recommendations(row, res["risk"])
    with b:
        render_shap(row)


{
    "Overview": page_overview, "Data Explorer": page_explorer, "Model Performance": page_models,
    "Feature Importance": page_importance, "Predict": page_predict, "Batch Scoring": page_batch,
    "Business Impact": page_business, "Customer Risk Analysis": page_samples,
}[page]()
